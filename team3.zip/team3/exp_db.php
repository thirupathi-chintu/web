<html>
<body>
<?php
$con=new MYSQLI("localhost","root","eswecha");
if($con->connect_error)
{
die("connection failed".$con->connect_error);
}
else{
//echo "connection established";
}
/*$sql="create database expenses";
if($con->query($sql)==TRUE)
{
echo"database created succesfully";
}
else
{
echo"error in creating database".$con->error;
}*/
$a=mysqli_select_db($con,'expenses');
if($a)
{
//echo"connection is done succesfully";
}
else
{
echo"error in connecting to database".$con->error;
}
/*$tab="create table dayexpense(type_of_expense varchar(20),Amount int(30),Type varchar(30),Date varchar(30))";
$r=mysqli_query($con,$tab);
if($r)
{
echo"table login is created";
}
else
{
echo"table is not created".$con->error;
}*/




$s=mysqli_query($con,'select * from dayexpense');
if(mysqli_num_rows($s)>0){

$s1=$_POST['s'];
$a="insert into dayexpense values('".$_POST["exp"]."','".$_POST["amn"]."','".$_POST["typ"]."','".$_POST["dat"]."')";
$s=mysqli_query($con,$a);
if($s)
echo ""."<br>";
else
die('values are not inserted');
	echo"Your type_of_expense:".$_POST["exp"]."<br>";
	echo"Your Amount:".$_POST["amn"]."<br>";
	echo"Your type :".$_POST["typ"]."<br>";
	echo"Your date:".$_POST["dat"]."<br>";


$con->close();
?>

<p><a href="project1.html">Another entery</a> </p>
</html>
</body>



