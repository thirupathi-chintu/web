<html>
<body>
<?php
function db_connect() {
	    $con = new MYSQLI("localhost","root","eswecha");
		//echo "sucess";
	    //return $con;
	    if (mysqli_connect_errno($con)) {
	    echo "Failed to connect to MySQL: " . mysqli_connect_error();
		}
		else{
		echo "sucess";
}
	}
/*function createtable(){
     $con = db_connect();
	$result = mysqli_query($con,"CREATE TABLE spent (type_of_expense varchar(30),Amount int(30),Type varchar(30),Date varchar(30))");
	if($result === false) {
	echo "table not created";
	}
	else{
	echo "table created" . mysqli_connect_error();
	}
}
function insertItem($item_name, $item_Amount , $item_Type, $item_Date) {
	$con = db_connect();
	$result = mysqli_query($con,"INSERT INTO spent(item_name,item_Amount,item_Type,item_Date) VALUES ('$item_name','$item_Amount','$item_Type','$item_Date')");
	
	if($result === false) {

		echo "Query unseccessful";;
	} else 
	    echo "Go back to <a href=\"index.php\">Home page</a>";
	}
	mysqli_close($con);
}
function retriveItem() {
	$con = db_connect();
	$sql = "SELECT id, item_name, item_Amount,item_Type,item_Date FROM spent";
	$result = mysqli_query($con, $sql);
	if (mysqli_num_rows($result) > 0)
	    while($row = mysqli_fetch_assoc($result)) {
	        echo "Name: " . $row["item_name"]. ", Amount: " . $row["item_Amount"]. ",Type: " . $row["item_Type"]. ",  Date: " . $row["item_Date"]. "<br>";
	    }
	} else {
	    echo "0 results";
	}
}
function totalExpenditure() {
	$con = db_connect();
	$result = mysqli_query($con,'SELECT SUM(item_Amount) AS value_sum FROM spent'); 
	$row = mysqli_fetch_assoc($result); 
	$sum = $row['value_sum'];
	echo "<b>".$sum."</b>";
}*/
?>
</body>
</html>




















