<?php
$conn= new mysqli("localhost","root","eswecha");
  if($conn->error)
  {
       echo $conn->error;
   }
  else{
        echo"database is connected\n";
   }
$sql="create database project";
if($conn->query($sql)===TRUE)
{
echo"\ndatabase is created";
}
else
{
echo"database is not created";
}
/*$d=mysqli_query($conn,$sql);
if(!$d)
echo "not created";*/
?>
