<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>
.mySlides {display:none;}
form{
width:30%;
padding:20px;
margin:auto;
background-color:orange;
}

form{border-radius: 10px;}
.button {
    background-color:green;
    border: none;
    color: white;
    padding: 20px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 2px 2px;
    cursor: pointer;
}

</style>
</head>
</style>
<body bgcolor="lightgrey">

<h2 class="w3-center"></h2>

<center><img class="mySlides" src="ww.jpg" style="width:60%">

  <img class="mySlides" src="xx.jpg" style="width:60%">
<img class="mySlides" src="ll.jpg" style="width:60%">
  
</center>

<script>
var slideIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
      x[i].style.display = "none"; 
    }
    slideIndex++;
    if (slideIndex > x.length) {slideIndex = 1} 
    x[slideIndex-1].style.display = "block"; 
    setTimeout(carousel, 2000); 
}
</script>
<left><form name="jump" action="home4.php" method="post" >
<center><h2 style="color:white;"></h2></center>
From:<select name="from">
<option value="Select City">Select City</option>
<option value="c">Vizag</option>
<option value="u">Chennai</option>
<option value="uk">Bangulore</option>
<option value="j">Hyderabad</option>
<option value="c">NewDelhi</option>
<option value="u">Mumbai</option>
<option value="uk">Pune</option>
<option value="j">Goa</option>
</select>&emsp;
To:<select name="to">
<option value="Select City">Select City</option>
<option value="c">Vizag</option>
<option value="u">Chennai</option>
<option value="uk">Bangulore</option>
<option value="j">Hyderabad</option>
<option value="c">NewDelhi</option>
<option value="u">Mumbai</option>
<option value="uk">Pune</option>
<option value="j">Goa</option>
</select></br></br>
Pick Up:&emsp;&emsp;
<input type="date" name="d"><br></br>
Drop Off:&emsp;
<input type="date" name="d"><br></br>
Pick Up At:
<input type="time" name="t"><br></br>
<select name="menu">
<option value="#">Select a car</option>
<option value="swift.html">swift</option>
<option value="innova.html">innova</option>
<option value="bolero.html">bolero</option>
<option value="waganor.html">waganor</option>
<option value="vw.html">volkswagen</option>
</select>
<center>
<button type="button" onClick="location=document.jump.menu.options[document.jump.menu.selectedIndex].value;" value="GO" class="button button4">GO</button></center>
</form>
</left>
</body>
</html>

<?php
$name6=$_POST["from"];
$name7=$_POST["to"];
$name8=$_POST["d"];
$name9=$_POST["d"];
$name10=$_POST["t"];
$name11=$_POST["menu"];
$conn= new mysqli("localhost","root","eswecha","project");
  if($conn->error)
  {
       echo $conn->error;
   }
  else{
        echo"\n";
   }
/*$sql="create database project";
if($conn->query($sql)===TRUE)
{
echo"\ndatabase is created";
}
else
{
echo"database is not created";
}
$sql="CREATE TABLE car2(fromarea varchar(30),toarea varchar(30),pickup varchar(20),dropoff varchar(20),pickupat varchar(30),selectcar varchar(30))";
if($conn->query($sql)===TRUE)
{
echo"table is created";
}
else
{
echo"table is not created";
}*/
$sql="insert into car2 values('$name6','$name7','$name8','$name9','$name10','$name11')";
if($conn->query($sql)===TRUE)
 {
echo "";
}
else
{
echo "something wrong";
}
?>
