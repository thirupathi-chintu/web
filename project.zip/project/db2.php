<?php
$name6=$_POST["sc"];
$name7=$_POST["nc"];
$name8=$_POST["date"];
$name9=$_POST["date"];
$name10=$_POST["time"];
$name11=$_POST["menu"];
$conn= new mysqli("localhost","root","eswecha","project");
  if($conn->error)
  {
       echo $conn->error;
   }
  else{
        echo"\n";
   }
/*$sql="create database project";
if($conn->query($sql)===TRUE)
{
echo"\ndatabase is created";
}
else
{
echo"database is not created";
}
$sql="CREATE TABLE car2(fromarea varchar(30),toarea varchar(30),pickup varchar(20),dropoff varchar(20),pickupat varchar(30),selectcar varchar(30))";
if($conn->query($sql)===TRUE)
{
echo"table is created";
}
else
{
echo"table is not created";
}*/
$sql="insert into car1 values('$name6','$name7','$name8','$name9','$name10','$name11')";
if($conn->query($sql)===TRUE)
 {
echo "";
}
else
{
echo "something wrong";
}
?>
