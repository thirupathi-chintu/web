
<?php
$name=$_POST["fn"];
$name2=$_POST["ln"];
$name3=$_POST["em"];
$name4=$_POST["mn"];
$name5=$_POST["psw"];
$conn= new mysqli("localhost","root","eswecha","internship");
  if($conn->error)
  {
       echo $conn->error;
   }
  else{
        echo"database is connected\n";
   }
/*$sql="create database internship";
if($conn->query($sql)===TRUE)
{
echo"\ndatabase is created";
}
else
{
echo"database is not created";
}
$query="CREATE TABLE student(firstname varchar(10),lastname varchar(10),email varchar(20),mobilenumber int(19),password varchar(10))";
if($conn->query($query)===TRUE)
{
echo"table is created";
}
else
{
echo"table is not created";
}*/
$sql="insert into student values('$name','$name2','$name3','$name4','$name5')";
if($conn->query($sql)===TRUE)
 {
echo "regi completed";
}
else
{
echo "somthing wrong";
}
?>

