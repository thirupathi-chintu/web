<?php
$name=$_POST["fn"];
$name2=$_POST["em"];
$name3=$_POST["psw"];
$name4=$_POST["mn"];
$name5=$_POST["gender"];
$name6=$_POST["sc"];
$name7=$_POST["nc"];
$name8=$_POST["date"];
$name9=$_POST["date"];
$name10=$_POST["time"];
$name11=$_POST["menu"];

$conn= new mysqli("localhost","root","eswecha","project");
  if($conn->error)
  {
       echo $conn->error;
   }
  else{
        echo"\n";
   }
/*$sql="create database project";
if($conn->query($sql)===TRUE)
{
echo"\ndatabase is created";
}
else
{
echo"database is not created";
}
$sql="CREATE TABLE car(name varchar(30),email varchar(30),password varchar(20),mobile varchar(20),gender varchar(30))";
if($conn->query($sql)===TRUE)
{
echo"table is created";
}
else
{
echo"table is not created";
}*/
$sql="insert into car values('$name','$name2','$name3','$name4','$name5','$name6','$name7','$name8','$name9','$name10','$name11')";
if($conn->query($sql)===TRUE)
 {
echo "Thank You!
            Your Booking Is successfull";
}
else
{
echo "something wrong";
}
?>
